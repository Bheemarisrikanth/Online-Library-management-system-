<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">
					<?php include('head.php'); ?>
				<div class="span2">
					<?php include('sidebar.php'); ?>
				</div>
				<div class="span10">
					<?php include('slider.php'); ?>
				</div>
			
				<div class="span2">
				<h4></h4>
			
				</div>
				<div class="span10">
				
				
				<?php include('thumbnail.php'); ?>
				
					
					<div class="text_content">
					<div class="abc">
					<!-- text content -->
					<h4>Vision</h4>
					<hr>
					<p>
					By 2016.  E.B.Magalona National High School is a center of learning were stackholders are conscientiously involved in loning holistic 
					individuals committed to positively respond to the needs of the school, community and the country.
					</p>
					<hr>
					<h4>Mission</h4>
					<hr>
					<p>
					To nurture students to become productive responsible citizens through the assistance of service - 
					oriented and highly competent internal and external stakeholders working in a harmonious relationship.
					</p>
					<hr>
					</div>
					</div>
					<!-- end content -->
				
				
				</div>
			
			</div>
		</div>
    </div>
<?php include('footer.php') ?>