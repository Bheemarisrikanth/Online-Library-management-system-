<?php include('header.php'); ?>
<?php include('navbar.php'); ?>

    <div class="container">
		<div class="margin-top">
			<div class="row">
					<?php include('head.php'); ?>
		
				<div class="span12">
					<?php include('signup_form.php'); ?>
				</div>
			
				
			</div>
		</div>
    </div>
<?php include('footer.php') ?>