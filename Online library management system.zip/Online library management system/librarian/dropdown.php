					<li>		
					<a href="borrow.php"  data-toggle="dropdown" ><i class="icon-file icon-large"></i> Transaction</a>
					<ul class="dropdown-menu">
					<li><a href="borrow.php"><i class="icon-pencil icon-large"></i>&nbsp;Borrow</a></li>
					<li><a href="return.php"><i class="icon-cog icon-large"></i>&nbsp;View Returned Books</a></li>
					<li><a href="view_borrow.php"><i class="icon-reorder icon-large"></i>&nbsp;View Borrowed Books</a></li>
					</ul>
					</li>